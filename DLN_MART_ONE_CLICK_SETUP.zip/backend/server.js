const express=require("express"),cors=require("cors"),crypto=require("crypto");
const Razorpay=require("razorpay");
const app=express(); app.use(cors()); app.use(express.json());
const PORT=process.env.PORT||3000;
const rz=(process.env.RAZORPAY_KEY_ID&&process.env.RAZORPAY_KEY_SECRET)?new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET}):null;

app.get("/api/health",(req,res)=>res.json({ok:true,service:"DLN MART",payments:!!rz}));
app.post("/api/payment/order",async(req,res)=>{
  if(!rz)return res.status(503).json({error:"Razorpay keys are not configured"});
  const amount=Math.round(Number(req.body.amount)*100);
  if(!Number.isFinite(amount)||amount<100)return res.status(400).json({error:"Invalid amount"});
  try{
    const order=await rz.orders.create({amount,currency:"INR",receipt:"DLN_"+Date.now(),payment_capture:1});
    res.json({id:order.id,amount:order.amount,currency:order.currency,keyId:process.env.RAZORPAY_KEY_ID});
  }catch(e){res.status(500).json({error:"Unable to create payment order"})}
});
app.post("/api/payment/verify",(req,res)=>{
  const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
  const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET||"").update(razorpay_order_id+"|"+razorpay_payment_id).digest("hex");
  if(!razorpay_signature||!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(razorpay_signature)))return res.status(400).json({verified:false});
  res.json({verified:true});
});
app.post("/api/payment/webhook",(req,res)=>{
  const raw=JSON.stringify(req.body);
  const sig=req.headers["x-razorpay-signature"]||"";
  const expected=crypto.createHmac("sha256",process.env.RAZORPAY_WEBHOOK_SECRET||"").update(raw).digest("hex");
  if(expected!==sig)return res.status(400).json({ok:false});
  res.json({ok:true});
});
app.listen(PORT,()=>console.log("DLN MART API on "+PORT));
