# Android / Play Store wrapper
Use Capacitor around the frontend:
1. npm install @capacitor/core @capacitor/cli
2. npx cap init "DLN MART" "com.dlnmart.app"
3. Put the deployed frontend URL or built frontend in the web assets.
4. npx cap add android
5. npx cap sync android
6. Open `android/` in Android Studio and create a signed AAB for Play Console.

A Play Store release still needs your developer account, app signing, privacy policy and production service credentials.
