# DLN MART — ONE PACKAGE

यह package DLN MART को real deployment तक ले जाने के लिए तैयार किया गया है।

## इसमें
Customer storefront, cart, checkout, COD, Razorpay server flow, order API,
admin foundation, Supabase/Postgres schema, delivery zones, auth foundation,
Render config और Android/Play Store wrapper instructions हैं।

## सबसे जरूरी बात
मैं तुम्हारे external accounts में बिना login/credentials के खुद service activate नहीं कर सकता।
इसलिए secret keys placeholders में हैं। Secret keys को frontend/GitHub में कभी मत डालना।

## शुरुआत
`SETUP_KEYS.txt` खोलो और उसके steps follow करो।
