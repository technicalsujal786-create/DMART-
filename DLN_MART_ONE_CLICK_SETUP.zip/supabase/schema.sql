create table if not exists public.products (
 id uuid primary key default gen_random_uuid(), name text not null, category text not null,
 price numeric(10,2) not null check(price>=0), image_url text, stock boolean default true,
 created_at timestamptz default now()
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id),
 total numeric(10,2) not null, address text not null, phone text not null,
 payment_method text not null, payment_status text default 'pending',
 status text default 'placed', latitude double precision, longitude double precision,
 created_at timestamptz default now()
);
create table if not exists public.order_items (
 id uuid primary key default gen_random_uuid(), order_id uuid references public.orders(id) on delete cascade,
 product_id uuid references public.products(id), quantity integer not null check(quantity>0),
 price numeric(10,2) not null
);
create table if not exists public.delivery_zones (
 id uuid primary key default gen_random_uuid(), name text not null, max_km numeric(5,2) not null,
 fee numeric(10,2) default 0, eta_minutes integer default 60, active boolean default true
);
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.delivery_zones enable row level security;
create policy "public products read" on public.products for select using (stock=true);
create policy "public zones read" on public.delivery_zones for select using (active=true);
create policy "users own orders" on public.orders for select using (auth.uid()=user_id);
create policy "users insert own orders" on public.orders for insert with check (auth.uid()=user_id);
create policy "users own items" on public.order_items for select using (
 exists(select 1 from public.orders o where o.id=order_id and o.user_id=auth.uid())
);
insert into public.delivery_zones(name,max_km,fee,eta_minutes) values
('Zone 1',3,0,30),('Zone 2',5,20,45),('Zone 3',8,30,60),('Zone 4',10,40,75)
on conflict do nothing;
