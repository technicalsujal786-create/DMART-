# DLN MART production setup

1. Create a Supabase project and run `supabase/schema.sql`.
2. Configure Supabase Phone Auth/OTP and an SMS provider.
3. Deploy `backend` to Render as a Node web service.
4. Add backend environment variables from `backend/.env.example`.
5. Create Razorpay API credentials and webhook; add them only to Render environment variables.
6. Put the Render API URL and Supabase publishable values into frontend config.
7. Serve frontend over HTTPS.
8. Test COD, payment success/failure, order status and delivery-zone rules before launch.
9. Build Android with Capacitor and sign an AAB for Play Store.

Secrets must never be placed in GitHub/frontend. Razorpay specifically requires keeping the API secret out of source control and the mobile build.
