// Copy to config.local.js for local use. Never commit secret keys.
window.DLN_CONFIG = {
  API_URL: "https://YOUR-RENDER-SERVICE.onrender.com",
  SUPABASE_URL: "https://YOUR_PROJECT.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "YOUR_SUPABASE_PUBLISHABLE_KEY",
  RAZORPAY_KEY_ID: "YOUR_RAZORPAY_KEY_ID"
};
