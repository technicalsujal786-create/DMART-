CREATE TABLE IF NOT EXISTS store_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO store_settings(key,value) VALUES
('minimum_order','99'),('delivery_fee','25'),('free_delivery_above','499'),('store_name','DLN MART')
ON CONFLICT(key) DO NOTHING;
