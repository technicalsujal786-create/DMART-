# DLN MART — Step 5 Customer Shopping App

This step adds a native Android customer app connected to the existing Express/PostgreSQL backend.

## Features
- Product list from `/api/products`
- Search via `/api/products?search=`
- Add products to local cart
- COD checkout
- Creates real orders via `/api/orders`
- Displays the real order ID/status returned by the server

## Run
1. Start PostgreSQL and initialize the server.
2. Start `server` on port 3000.
3. Open `android/` in Android Studio.
4. Run on an Android emulator. The app uses `http://10.0.2.2:3000/api` for the emulator.
5. For a physical phone, change `API` in `MainActivity.java` to the LAN/HTTPS address of the backend.

This is a development build foundation. Before public Play Store release, add HTTPS, authentication/customer accounts, payment gateway, stock reservation, delivery zones, order history, secure secrets, validation, crash reporting and production hosting.
