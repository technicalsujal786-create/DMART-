# DLN MART Step 8 — Checkout & Delivery Summary

Added to the customer Android app:
- Dedicated checkout screen
- Cart subtotal display
- Delivery fee calculation from `/api/settings`
- Free-delivery threshold display
- Minimum-order validation before checkout
- Delivery name, phone and address form
- COD payment selection
- Order confirmation showing order ID, subtotal, delivery fee and total

Online payment UI is intentionally not activated yet; the next payment step should integrate a real gateway with server-side verification.

API base remains `http://10.0.2.2:3000/api` for Android emulator development. Use a deployed HTTPS API before production/Play Store release.
