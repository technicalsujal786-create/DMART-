# DLN MART V3 — Real App Foundation
Includes Android customer app, Node/Express API, PostgreSQL schema, and admin web panel.
This is the real project foundation, not a finished Play Store release. Configure database, HTTPS API URL, payment keys, privacy policy, and signing before production.

Backend: `cd server && npm install && npm run init-db && npm start`
Android: open `android` in Android Studio and change `API_BASE_URL` in MainActivity.java to your deployed HTTPS API.
Admin: open `admin/index.html` and enter the API URL. Demo admin credentials must be changed before production.
