# DLN MART — Step 6: Customer Accounts & Orders

Added:
- Customer registration and login with bcrypt + JWT
- Customer profile endpoint
- Customer-specific My Orders endpoint
- Individual order tracking endpoint
- Orders can be linked to a customer account
- Existing admin/product/order APIs retained

## Database
Run `server/migrate-step6.sql` against the existing PostgreSQL database, or initialize a fresh database with `server/schema.sql`.

## API
POST /api/auth/register
POST /api/auth/login
GET /api/me (Bearer customer token)
GET /api/my/orders (Bearer customer token)
GET /api/my/orders/:id (Bearer customer token)

## Important
Set a strong `JWT_SECRET` in `.env` before production. The Android app still uses `10.0.2.2` for local emulator testing; replace it with your HTTPS production API URL before Play Store release.
