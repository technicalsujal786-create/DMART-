# DLN MART Step 4 — Admin & Inventory Upgrade

Based on DLN_MART_V3_REAL.

## Added
- Admin dashboard statistics
- Add categories
- Edit product name/price
- Product stock on/off
- Product image URL field
- Order status management
- Safer admin UI rendering

## Run backend
cd server
npm install
npm run init-db
npm start

## Admin
Open admin/index.html and set the deployed API URL.

## Production checklist
- Use a strong JWT_SECRET
- Use HTTPS
- Change admin password
- Configure PostgreSQL securely
- Add payment gateway before accepting online payments
- Add privacy policy/terms
- Build and sign Android release after testing
