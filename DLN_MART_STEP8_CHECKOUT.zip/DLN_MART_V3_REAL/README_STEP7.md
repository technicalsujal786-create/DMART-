# DLN MART Step 7 — Delivery Rules

Added:
- Store settings API
- Minimum order validation (default ₹99)
- Delivery fee (default ₹25)
- Free delivery above ₹499
- Order response includes subtotal and delivery fee

Run migration before starting server:
`psql "$DATABASE_URL" -f migrate-step7.sql`

This step keeps COD as the working payment method. Online payment can be integrated later after production backend/security setup.
